/**
 * Módulos essenciais
 */
const express = require('express');
const cors = require('cors');
const os = require('os');
const bcrypt = require('bcrypt');
require('dotenv').config();
const { db } = require('./utils/firebase');

/**
 * Importação de rotas modulares
 */
const alunoRoutes = require('./routes/alunoRoutes');
const professorRoutes = require('./routes/professorRoutes');
const exercicioRoutes = require('./routes/exercicioRoutes');
const treinoRoutes = require('./routes/treinoRoutes');
const historicoRoutes = require('./routes/historicoRoutes');
const mlRoutes = require('./routes/mlRoutes');

/**
 * Configuração do Express
 */
const app = express();
const PORT = process.env.PORT || 3000;

// ==================== MIDDLEWARES GLOBAIS ====================
// Configure CORS para permitir todas as origens
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// ==================== ROTEAMENTO PRINCIPAL ====================
app.get('/', (req, res) => {
  const ipAddress = getLocalIPAddress();
  res.send(`Mundo Fit API 2.0\nAcesse: http://${ipAddress}:${PORT}`);
});

// Se estiver usando Express.js
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'online',
    timestamp: new Date().toISOString()
  });
});

// Rotas existentes
app.use('/alunos', alunoRoutes);
app.use('/professores', professorRoutes);
app.use('/exercicios', exercicioRoutes);
app.use('/treinos', treinoRoutes);
app.use('/historicos', historicoRoutes);
app.use('/ml', mlRoutes);

// ==================== NOVAS ROTAS DE AUTENTICAÇÃO ====================
app.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    console.log(`Tentativa de login: ${email}`);

    // Verificação do Admin
    if (email === process.env.ADMIN_EMAIL && senha === process.env.ADMIN_SENHA) {
      return res.json({ tipoUsuario: 'admin' });
    }

    // Verificação de Professores
    const professoresSnapshot = await db.collection('professores').get();
    const professor = professoresSnapshot.docs.find(doc => doc.data().email_professor === email);
    
    if (professor && await bcrypt.compare(senha, professor.data().cd_senha_pf)) {
      return res.json({ 
        tipoUsuario: 'professor',
        id: professor.id,
        nome: professor.data().nm_professor
      });
    }

    // Verificação de Alunos
    const alunosSnapshot = await db.collection('alunos').get();
    const aluno = alunosSnapshot.docs.find(doc => doc.data().email_aluno === email);
    
    if (aluno && await bcrypt.compare(senha, aluno.data().cd_senha_al)) {
      return res.json({ 
        tipoUsuario: 'aluno',
        id: aluno.id,
        nome: aluno.data().nm_aluno
      });
    

      
    }

    res.status(401).json({ mensagem: 'Credenciais inválidas' });

  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ error: 'Erro interno no servidor' });
  }
});

app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'online',
    versao: '2.0.0',
    timestamp: new Date().toISOString()
  });
});

// ==================== INICIALIZAÇÃO DO SERVIDOR ====================
app.listen(PORT, () => {
  const ip = getLocalIPAddress();
  console.log(`
  =============================================
  MundoFit Backend 2.0 - ONLINE 🚀
  Local:    http://localhost:${PORT}
  Rede:     http://${ip}:${PORT}
  Ambiente: ${process.env.NODE_ENV || 'desenvolvimento'}
  =============================================`);
});

/**
 * Funções auxiliares
 */
function getLocalIPAddress() {
  const interfaces = os.networkInterfaces();
  for (const interfaceName of Object.values(interfaces)) {
    for (const iface of interfaceName) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}