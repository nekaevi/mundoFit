const express = require('express');
const router = express.Router();
const { trainModel, predict } = require('../ml/recommender');

// Treinamento do modelo ao iniciar o servidor
let modeloTreinado = null;
trainModel()
  .then(m => {
    modeloTreinado = m;
    console.log('✅ Modelo carregado no router');
  })
  .catch(err => console.error('❌ Falha ao carregar modelo:', err));

// Mapeamento de objetivos
const objetivos = [
  'Funcional',
  'Hipertrofia', 
  'Perda de Peso',
  'Cardio'
];

// Validação de entrada
const validarEntrada = (dados) => {
  const camposObrigatorios = ['idade', 'genero', 'peso', 'altura', 'experiencia'];
  const erros = [];
  
  camposObrigatorios.forEach(campo => {
    if (dados[campo] === undefined || dados[campo] === null) {
      erros.push(`Campo obrigatório faltando: ${campo}`);
    }
  });

  // Conversão e validação de tipos
  const idade = Number(dados.idade);
  const peso = Number(dados.peso);
  const altura = Number(dados.altura);
  const experiencia = Number(dados.experiencia);
  
  if (isNaN(idade)) erros.push('Idade inválida');
  if (isNaN(peso)) erros.push('Peso inválido');
  if (isNaN(altura)) erros.push('Altura inválida');
  if (isNaN(experiencia)) erros.push('Experiência inválida');
  
  return {
    valido: erros.length === 0,
    erros,
    dadosConvertidos: {
      idade,
      genero: dados.genero.toLowerCase() === 'masculino' ? 1 : 0,
      peso,
      altura,
      experiencia
    }
  };
};

router.post('/recomendar', async (req, res) => {
  try {
    // Validação inicial
    const validacao = validarEntrada(req.body);
    if (!validacao.valido) {
      return res.status(400).json({
        erro: 'Dados inválidos',
        detalhes: validacao.erros
      });
    }

    // Preparar array de entrada
    const entrada = [
      validacao.dadosConvertidos.idade,
      validacao.dadosConvertidos.genero,
      validacao.dadosConvertidos.peso,
      validacao.dadosConvertidos.altura,
      validacao.dadosConvertidos.experiencia
    ];

    // Verificar se o modelo está pronto
    if (!modeloTreinado) {
      return res.status(503).json({
        erro: 'Serviço não disponível',
        detalhes: 'Modelo ainda não foi treinado'
      });
    }

    // Fazer predição
    const indice = await predict(entrada);
    
    // Validar índice retornado
    if (indice < 0 || indice >= objetivos.length) {
      throw new Error('Índice de objetivo inválido retornado pelo modelo');
    }

    // Resposta de sucesso
    res.json({
      recomendacao: objetivos[indice],
      indice,
      parametrosUsados: validacao.dadosConvertidos,
      timestamp: new Date().toISOString()
    });

  } catch (err) {
    console.error('Erro na recomendação:', err);
    
    const statusCode = err.message.includes('não está pronto') ? 503 : 500;
    
    res.status(statusCode).json({
      erro: 'Falha na recomendação',
      detalhes: process.env.NODE_ENV === 'development' ? err.message : 'Tente novamente mais tarde'
    });
  }
});

module.exports = router;