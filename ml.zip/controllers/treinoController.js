// controllers/treinoController.js
const { db } = require('../utils/firebase');

exports.createTreino = async (req, res) => {
  try {
    const treinoData = req.body;
    const treinoRef = await db.collection('treinos').add({
      nm_treino: treinoData.nm_treino,
      nm_fk_exercicio: treinoData.nm_fk_exercicio,
      cd_fk_exercicio: treinoData.cd_fk_exercicio,
      cd_fk_aluno: treinoData.cd_fk_aluno,
      cd_fk_professor: treinoData.cd_fk_professor,
      dt_treino: treinoData.dt_treino || new Date(),
      ds_objetivo: treinoData.ds_objetivo,
      ds_observacao: treinoData.ds_observacao,
      nm_dia_semana: treinoData.nm_dia_semana,
    });
    res.status(201).json({ id: treinoRef.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getTreinos = async (req, res) => {
  try {
    const snapshot = await db.collection('treinos').get();
    const treinos = [];
    snapshot.forEach(doc => treinos.push({ id: doc.id, ...doc.data() }));
    res.status(200).json(treinos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getTreinoById = async (req, res) => {
  try {
    const treinoDoc = await db.collection('treinos').doc(req.params.id).get();
    if (!treinoDoc.exists) {
      return res.status(404).json({ error: 'Treino não encontrado' });
    }
    res.status(200).json({ id: treinoDoc.id, ...treinoDoc.data() });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateTreino = async (req, res) => {
  try {
    const treinoData = req.body;
    await db.collection('treinos').doc(req.params.id).update(treinoData);
    console.log("=============================================")
    res.status(200).json({ message: 'Treino atualizado com sucesso' });
    console.log("=============================================")

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteTreino = async (req, res) => {
  try {
    await db.collection('treinos').doc(req.params.id).delete();
    console.log("=============================================")
    res.status(200).json({ message: 'Treino removido com sucesso' });
    console.log("=============================================")

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
