// controllers/historicoController.js
const { db } = require('../utils/firebase');

exports.createHistorico = async (req, res) => {
  try {
    const historicoData = req.body;
    const historicoRef = await db.collection('historicos').add({
      cd_fk_aluno: historicoData.cd_fk_aluno,
      cd_fk_treino: historicoData.cd_fk_treino,
      dt_treino_realizado: historicoData.dt_treino_realizado || new Date(),
      cd_fk_peso: historicoData.cd_fk_peso,
      ds_comentarios: historicoData.ds_comentarios,
    });
    res.status(201).json({ id: historicoRef.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getHistoricos = async (req, res) => {
  try {
    const snapshot = await db.collection('historicos').get();
    const historicos = [];
    snapshot.forEach(doc => historicos.push({ id: doc.id, ...doc.data() }));
    res.status(200).json(historicos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getHistoricoById = async (req, res) => {
  try {
    const histDoc = await db.collection('historicos').doc(req.params.id).get();
    if (!histDoc.exists) {
      return res.status(404).json({ error: 'Registro histórico não encontrado' });
    }
    res.status(200).json({ id: histDoc.id, ...histDoc.data() });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateHistorico = async (req, res) => {
  try {
    const historicoData = req.body;
    await db.collection('historicos').doc(req.params.id).update(historicoData);
    res.status(200).json({ message: 'Histórico atualizado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteHistorico = async (req, res) => {
  try {
    await db.collection('historicos').doc(req.params.id).delete();
    res.status(200).json({ message: 'Histórico removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
