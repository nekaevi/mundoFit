// controllers/alunoController.js

// Controller responsável pela criação e edição das coisas referentes à "Aluno"

// Importação dos requires
const { db } = require('../utils/firebase');

// Biblioteca responsável por fazer a encriptação de senhas de usuário aluno:
const bcrypt = require('bcrypt');
const saltRounds = 10;

// Função que exporta a criação de aluno, pegando toda requisição e salvando no banco de dados:
exports.createAluno = async (req, res) => {
  try {
    const alunoData = req.body;
    const hashedPassword = await bcrypt.hash(alunoData.cd_senha_al, saltRounds);
    const alunoRef = await db.collection('alunos').add({
      nm_aluno: alunoData.nm_aluno,
      status_aluno: alunoData.status_aluno || 'ativo',
      email_aluno: alunoData.email_aluno,
      cd_senha_al: hashedPassword,
      dt_cadastro: new Date(),
      cd_peso: alunoData.cd_peso,
      cd_peso_inicial: alunoData.cd_peso_atual,
      cd_peso_meta: alunoData.cd_peso,
      cd_altura: alunoData.cd_altura,
      ic_genero:alunoData.ic_genero,
      nm_experiencia:alunoData.nm_experiencia,
    });
    res.status(201).json({ id: alunoRef.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


// Função que exporta o get de alunos, pegando toda requisição e mostrando ao requisitante:
exports.getAlunos = async (req, res) => {
  try {
    const snapshot = await db.collection('alunos').get();
    const alunos = [];
    snapshot.forEach(doc => alunos.push({ id: doc.id, ...doc.data() }));
    res.status(200).json(alunos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getAlunoById = async (req, res) => {
  try {
    const alunoDoc = await db.collection('alunos').doc(req.params.id).get();
    if (!alunoDoc.exists) {
      return res.status(404).json({ error: 'Aluno não encontrado' });
    }
    res.status(200).json({ id: alunoDoc.id, ...alunoDoc.data() });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateAluno = async (req, res) => {
  try {
    const alunoData = req.body;
    // Se for atualizar a senha, opcionalmente você pode aplicar hash novamente
    if (alunoData.cd_senha_al) {
      alunoData.cd_senha_al = await bcrypt.hash(alunoData.cd_senha_al, saltRounds);
    }
    await db.collection('alunos').doc(req.params.id).update(alunoData);
    res.status(200).json({ message: 'Aluno atualizado com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteAluno = async (req, res) => {
  try {
    await db.collection('alunos').doc(req.params.id).delete();
    res.status(200).json({ message: 'Aluno removido com sucesso' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
