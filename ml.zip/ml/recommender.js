const KNN = require('ml-knn');
const { MinMaxScaler } = require('ml-preprocessing');

let knn = null;
let scaler = null;

// Dados ampliados e melhor distribuídos
const X = [
  // Funcional (0)
  [25, 0, 70, 175, 1, 0],
  [22, 0, 65, 165, 0, 0],
  [28, 1, 60, 170, 2, 0],
  [35, 0, 80, 180, 1, 0],
  
  // Hipertrofia (1)
  [30, 1, 80, 180, 2, 1],
  [28, 1, 90, 170, 3, 1],
  [24, 0, 75, 182, 1, 1],
  [32, 1, 85, 175, 2, 1],
  
  // Perda de Peso (2)
  [35, 0, 90, 160, 2, 2],
  [27, 1, 70, 168, 1, 2],
  [40, 0, 95, 172, 0, 2],
  [31, 1, 85, 180, 1, 2],
  
  // Cardio (3)
  [29, 0, 68, 170, 2, 3],
  [26, 1, 72, 176, 1, 3],
  [33, 0, 75, 165, 3, 3],
  [23, 1, 65, 160, 0, 3]
];

// Saídas correspondentes
const y = [0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3];

async function trainModel() {
  try {
    console.log("🚀 Iniciando treinamento do modelo...");
    
    // Normalização dos dados
    scaler = new MinMaxScaler();
    const X_normalized = scaler.fitTransform(X);

    // Treinamento com loading simulation
    const loadInterval = setInterval(() => process.stdout.write('.'), 500);
    
    knn = new KNN(X_normalized, y, { 
      k: 5,  // Valor otimizado para o novo dataset
      distance: 'euclidean'
    });

    await new Promise(resolve => setTimeout(resolve, 2000));
    clearInterval(loadInterval);
    
    console.log("\n🎉 Modelo treinado com sucesso!");
    console.log("▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄");
    return knn;

  } catch (err) {
    console.error("❌ Falha no treinamento:", err);
    throw err;
  }
}

async function predict(inputData) {
  if (!knn || !scaler) {
    throw new Error("Modelo não está pronto");
  }

  // Validação adicional
  if (!Array.isArray(inputData) || inputData.length !== 6) {
    throw new Error("Formato de dados inválido");
  }

  // Normalização da entrada
  const normalizedInput = scaler.transform([inputData]);
  const prediction = knn.predict(normalizedInput);
  
  return prediction[0];
}

module.exports = { trainModel, predict };